import { NextResponse } from "next/server";
import webpush from "web-push";
import { requireAdmin } from "@/lib/auth/admin";

type PushRow = {
  id: string;
  client_id: string;
  endpoint: string;
  p256dh: string;
  auth: string;
};

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const { supabase } = await requireAdmin();
  const payload = await request.json().catch(() => ({}));
  const clientIds = Array.isArray(payload.clientIds) ? payload.clientIds.filter(Boolean) : [];
  const title = String(payload.title || "neilzzbyanto").slice(0, 120);
  const message = String(payload.message || "Ai o notificare nouă.").slice(0, 240);

  const publicKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
  const privateKey = process.env.VAPID_PRIVATE_KEY;
  const subject = process.env.VAPID_SUBJECT || "mailto:hello@neilzzbyanto.local";

  if (!publicKey || !privateKey) {
    return NextResponse.json({ ok: false, reason: "missing_vapid_keys", sent: 0, failed: 0 });
  }

  if (clientIds.length === 0) {
    return NextResponse.json({ ok: false, reason: "no_clients", sent: 0, failed: 0 });
  }

  webpush.setVapidDetails(subject, publicKey, privateKey);

  const { data, error } = await supabase
    .from("push_subscriptions")
    .select("id,client_id,endpoint,p256dh,auth")
    .in("client_id", clientIds);

  if (error) {
    return NextResponse.json({ ok: false, reason: error.message, sent: 0, failed: 0 });
  }

  const subscriptions = (data || []) as PushRow[];
  let sent = 0;
  let failed = 0;

  await Promise.all(
    subscriptions.map(async (row) => {
      try {
        await webpush.sendNotification(
          {
            endpoint: row.endpoint,
            keys: { p256dh: row.p256dh, auth: row.auth },
          },
          JSON.stringify({
            title,
            body: message,
            message,
            tag: `neilzz-custom-${Date.now()}`,
            url: "/account?tab=notifications",
          }),
        );
        sent += 1;
      } catch (err: any) {
        failed += 1;
        const statusCode = Number(err?.statusCode || 0);
        if (statusCode === 404 || statusCode === 410) {
          await supabase.from("push_subscriptions").delete().eq("id", row.id);
        }
      }
    }),
  );

  return NextResponse.json({ ok: true, sent, failed, total: subscriptions.length });
}

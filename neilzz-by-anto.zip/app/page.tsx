"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowUpRight, CalendarDays, Camera, CheckCircle2, Clock3, Crown, Images, ShieldCheck, Sparkles, Star } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { SiteHeader } from "@/components/site-header";
import { createClient } from "@/lib/supabase/client";

const INSTAGRAM_URL = "https://instagram.com/neilzz_by.anto";

const defaultHomepageContent: HomepageContent = {
  badge: "Private nail atelier",
  titleLine1: "Quiet luxury.",
  titleLine2: "Perfect finish.",
  subtitle: "Forme curate, detalii fine și un finish premium — gândit ca o experiență privată, nu ca un template.",
  primaryCta: "Vezi galeria",
  secondaryCta: "Programează-te",
  instagramHandle: "@neilzz_by.anto",
  instagramUrl: INSTAGRAM_URL,
};

type GalerieImage = {
  id: string;
  title: string | null;
  image_url: string;
};

type BookingDay = {
  id: string;
  date_label: string;
  day_label: string | null;
  status: string;
  note: string | null;
  position: number | null;
};

type SiteSettings = {
  featuredClient?: boolean;
  featuredDesign?: boolean;
  featuredReview?: boolean;
  publicBookingEnabled?: boolean;
  appStatus?: string;
};

type HomepageContent = {
  badge: string;
  titleLine1: string;
  titleLine2: string;
  subtitle: string;
  primaryCta: string;
  secondaryCta: string;
  instagramHandle: string;
  instagramUrl: string;
};

type PublicReview = {
  id: string;
  name: string | null;
  rating: number | null;
  text: string;
  is_featured?: boolean | null;
  photo_url?: string | null;
};

type FeaturedClient = {
  id: string;
  full_name: string | null;
  visit_count: number | null;
  avatar_url: string | null;
};

const fallbackBooking: BookingDay[] = [
  { id: "b1", date_label: "23 martie", day_label: "Luni", status: "full", note: "Full", position: 1 },
  { id: "b2", date_label: "24 martie", day_label: "Marți", status: "available", note: "1 loc liber", position: 2 },
  { id: "b3", date_label: "25 martie", day_label: "Miercuri", status: "limited", note: "Locuri limitate", position: 3 },
];

function statusLabel(status: string, note?: string | null) {
  if (note) return note;
  if (status === "full") return "Full";
  if (status === "vacation") return "Concediu";
  if (status === "limited") return "Locuri limitate";
  return "Disponibil";
}

function displayDateLabel(dateLabel: string) {
  const clean = dateLabel.trim();
  if (/^\d{1,2}$/.test(clean)) return `${clean} iulie`;
  return clean;
}

function statusClass(status: string) {
  if (status === "full") return "status-pill status-full";
  if (status === "vacation") return "status-pill status-vacation";
  if (status === "limited") return "status-pill status-limited";
  return "status-pill status-available";
}

function statusDotClass(status: string) {
  if (status === "full") return "bg-red-300 shadow-[0_0_22px_rgba(252,165,165,.78)]";
  if (status === "vacation") return "bg-amber-300 shadow-[0_0_22px_rgba(252,211,77,.72)]";
  if (status === "limited") return "bg-yellow-300 shadow-[0_0_22px_rgba(253,224,71,.72)]";
  return "bg-emerald-300 shadow-[0_0_22px_rgba(110,231,183,.74)]";
}

function Reveal({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28, filter: "blur(12px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, margin: "-90px" }}
      transition={{ duration: 0.72, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function LuxuryButton({ href, children, solid = false }: { href: string; children: React.ReactNode; solid?: boolean }) {
  return (
    <motion.a
      href={href}
      target={href.startsWith("http") ? "_blank" : undefined}
      rel={href.startsWith("http") ? "noopener noreferrer" : undefined}
      whileHover={{ y: -3, scale: 1.018 }}
      whileTap={{ scale: 0.98 }}
      className={
        solid
          ? "lux-action lux-action-soft group inline-flex min-h-12 items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold transition md:px-6 md:py-3.5"
          : "lux-action group inline-flex min-h-12 items-center justify-center gap-2 rounded-full border border-[var(--line)] bg-[var(--panel)] px-5 py-3 text-sm font-semibold text-[var(--text)] backdrop-blur-xl transition hover:bg-[var(--panel-strong)] md:px-6 md:py-3.5"
      }
    >
      {children}
      <ArrowUpRight className="h-4 w-4 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
    </motion.a>
  );
}

type MobileRole = "loading" | "guest" | "client" | "admin";

function MobileBottomNav({ instagramUrl }: { instagramUrl: string }) {
  const [role, setRole] = useState<MobileRole>("loading");

  useEffect(() => {
    let active = true;
    const supabase = createClient();

    async function loadRole() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!active) return;
      if (!user) {
        setRole("guest");
        return;
      }

      let { data: profile } = await supabase.from("profiles").select("role,email").eq("id", user.id).maybeSingle();
      if (!profile && user.email) {
        const retry = await supabase.from("profiles").select("role,email").ilike("email", user.email).maybeSingle();
        profile = retry.data;
      }

      const adminList = (process.env.NEXT_PUBLIC_ADMIN_EMAILS || process.env.NEXT_PUBLIC_ADMIN_EMAIL || "")
        .split(",")
        .map((email) => email.trim().toLowerCase())
        .filter(Boolean);
      const metaRole = typeof user.user_metadata?.role === "string" ? user.user_metadata.role.toLowerCase() : "";
      const email = (user.email || profile?.email || "").toLowerCase();
      const isAdmin = profile?.role === "admin" || metaRole === "admin" || adminList.includes(email);
      setRole(isAdmin ? "admin" : "client");
    }

    loadRole();
    const { data } = supabase.auth.onAuthStateChange(() => window.setTimeout(loadRole, 0));
    const onFocus = () => loadRole();
    window.addEventListener("focus", onFocus);

    return () => {
      active = false;
      data.subscription.unsubscribe();
      window.removeEventListener("focus", onFocus);
    };
  }, []);

  const baseClass = "rounded-full px-2 py-2 text-center transition active:scale-95";
  const mutedClass = `${baseClass} text-[var(--muted)]`;
  const strongClass = `${baseClass} font-semibold text-[var(--text)]`;

  return (
    <nav className="neilzz-mobile-nav fixed bottom-[calc(.85rem+env(safe-area-inset-bottom))] left-1/2 z-50 grid w-[calc(100%-1.25rem)] max-w-md -translate-x-1/2 grid-cols-5 items-center rounded-full border border-[var(--line)] bg-[color-mix(in_srgb,var(--bg)_84%,transparent)] px-2 py-2 text-[11px] font-medium shadow-[0_20px_80px_rgba(0,0,0,.45)] backdrop-blur-2xl md:hidden">
      {role === "admin" ? (
        <>
          <Link href="/" className={mutedClass}>Home</Link>
          <Link href="/gallery" className={mutedClass}>Galerie</Link>
          <Link href="/dashboard" className={strongClass}>Dashboard</Link>
          <Link href="/account" className={mutedClass}>Account</Link>
          <a href="/auth/logout" className={strongClass}>Logout</a>
        </>
      ) : role === "client" ? (
        <>
          <Link href="/" className={mutedClass}>Home</Link>
          <Link href="/gallery" className={mutedClass}>Galerie</Link>
          <Link href="/booking" className={mutedClass}>Booking</Link>
          <Link href="/account" className={strongClass}>Account</Link>
          <a href="/auth/logout" className={strongClass}>Logout</a>
        </>
      ) : (
        <>
          <Link href="/" className={mutedClass}>Home</Link>
          <Link href="/gallery" className={mutedClass}>Galerie</Link>
          <Link href="/booking" className={mutedClass}>Booking</Link>
          <Link href="/login" className={strongClass}>Login</Link>
          <Link href="/register" className="neilzz-register-pill rounded-full px-2 py-2 text-center text-[11px] font-extrabold transition active:scale-95">Register</Link>
        </>
      )}
    </nav>
  );
}

function SparkleField() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <span className="sparkle left-[12%] top-[19%]" />
      <span className="sparkle left-[39%] top-[34%] [animation-delay:1.4s]" />
      <span className="sparkle right-[18%] top-[27%] [animation-delay:2.3s]" />
      <span className="sparkle bottom-[28%] left-[45%] [animation-delay:3.2s]" />
      <span className="sparkle bottom-[18%] right-[13%] [animation-delay:4.1s]" />
      <span className="sparkle right-[34%] bottom-[38%] [animation-delay:5.2s]" />
    </div>
  );
}

function AtelierPreview({ nextBooking }: { nextBooking: BookingDay }) {
  return (
    <div className="home-atelier-preview home-atelier-preview-v91">
      <div className="home-atelier-glow home-atelier-glow-a" />
      <div className="home-atelier-glow home-atelier-glow-b" />
      <div className="home-showcase-card home-showcase-main">
        <p className="lux-label">Experience flow</p>
        <h3 className="editorial-title mt-4 text-5xl leading-[0.9]">Inspo board.<br />Clean shape.<br />Premium finish.</h3>
        <p className="mt-5 max-w-sm text-sm leading-7 text-[var(--muted)]">Un preview elegant până când urci pozele reale. Când galeria are lucrări, zona asta devine automat showcase cu imagini.</p>
        <div className="mt-7 grid gap-3 sm:grid-cols-3">
          {["Inspirație", "Formă", "Finish"].map((item) => <div key={item} className="home-process-chip">{item}</div>)}
        </div>
      </div>
      <div className="home-showcase-card home-showcase-booking">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="lux-label">Booking</p>
            <p className="mt-3 font-serif text-4xl">{displayDateLabel(nextBooking.date_label)}</p>
          </div>
          <span className={statusClass(nextBooking.status)}>{statusLabel(nextBooking.status, nextBooking.note)}</span>
        </div>
      </div>
      <div className="home-showcase-card home-showcase-rank">
        <Crown className="h-5 w-5 text-[var(--rose-strong)]" />
        <div>
          <p className="lux-label">Client portal</p>
          <p className="mt-2 font-serif text-3xl">Rewards, review-uri și inspirații</p>
        </div>
      </div>
    </div>
  );
}

function RealGalleryPreview({ images }: { images: GalerieImage[] }) {
  const first = images[0];
  if (!first) return null;
  return (
    <motion.div
      initial={{ opacity: 0, x: 42, filter: "blur(18px)" }}
      animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
      transition={{ duration: 0.9, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
      className="relative hidden min-h-[560px] lg:block"
    >
      <div className="absolute inset-0 rounded-[3rem] bg-[var(--rose)]/10 blur-[110px]" />
      <div className="absolute left-[4%] top-[2%] w-[66%] overflow-hidden rounded-[2.2rem] border border-[var(--line)] bg-[var(--panel)] p-3 shadow-[0_45px_130px_var(--shadow)] backdrop-blur-2xl">
        <div className="relative aspect-[4/5] overflow-hidden rounded-[1.65rem] bg-[#10060b]">
          <Image src={first.image_url} alt={first.title || "neilzzbyanto"} fill priority sizes="(min-width: 1024px) 38vw, 82vw" className="object-cover opacity-90 saturate-[0.92]" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/16 to-transparent" />
          <div className="absolute bottom-7 left-7 right-5">
            <p className="text-[0.58rem] uppercase tracking-[0.45em] text-white/48">signature</p>
            <p className="mt-2 font-serif text-5xl text-white">{first.title || "Private finish"}</p>
          </div>
        </div>
      </div>
      {images[1] && (
        <div className="absolute right-[2%] top-[19%] w-[43%] overflow-hidden rounded-[1.8rem] border border-[var(--line)] bg-[var(--panel)] p-3 shadow-[0_35px_110px_var(--shadow)] backdrop-blur-2xl">
          <div className="relative aspect-[3/4] overflow-hidden rounded-[1.35rem] bg-[#10060b]">
            <Image src={images[1].image_url} alt={images[1].title || "neilzzbyanto"} fill sizes="(min-width: 1024px) 25vw, 62vw" className="object-cover opacity-86 saturate-[0.92]" />
          </div>
        </div>
      )}
      {images[2] && (
        <div className="absolute bottom-[5%] left-[31%] w-[56%] overflow-hidden rounded-[1.8rem] border border-[var(--line)] bg-[var(--panel)] p-3 shadow-[0_35px_110px_var(--shadow)] backdrop-blur-2xl">
          <div className="relative aspect-[5/3] overflow-hidden rounded-[1.35rem] bg-[#10060b]">
            <Image src={images[2].image_url} alt={images[2].title || "neilzzbyanto"} fill sizes="(min-width: 1024px) 30vw, 75vw" className="object-cover opacity-86 saturate-[0.92]" />
          </div>
        </div>
      )}
    </motion.div>
  );
}

function InstagramBlock({ images, content }: { images: GalerieImage[]; content: HomepageContent }) {
  const hasReal = images.length > 0;
  const posts = images.slice(0, 6);
  return (
    <section className="relative z-10 px-5 py-12 md:px-8 md:py-16">
      <Reveal>
        <div className="home-instagram-shell mx-auto max-w-[1320px] overflow-hidden rounded-[2.6rem] p-6 md:p-9">
          <div className="flex flex-col gap-7 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="lux-label">Instagram</p>
              <h2 className="editorial-title mt-5 text-5xl leading-[0.92] md:text-7xl">Postări reale din atelier.</h2>
              <p className="mt-5 max-w-2xl text-sm leading-7 text-[var(--muted)] md:text-base">
                Folosim pozele urcate în galerie ca preview de Instagram. Așa nu apar carduri fake și nu se repetă logo-ul.
              </p>
            </div>
            <LuxuryButton href={content.instagramUrl || INSTAGRAM_URL} solid><Camera className="h-4 w-4" />{content.instagramHandle || "@neilzz_by.anto"}</LuxuryButton>
          </div>

          {hasReal ? (
            <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-6">
              {posts.map((image, index) => (
                <a
                  key={image.id}
                  href={content.instagramUrl || INSTAGRAM_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={index === 0 ? "home-instagram-post home-instagram-post-featured group" : "home-instagram-post group"}
                >
                  <Image src={image.image_url} alt={image.title || "Postare neilzzbyanto"} fill sizes="(min-width: 1024px) 22vw, 80vw" className="object-cover transition duration-700 group-hover:scale-105" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/74 via-black/8 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <p className="text-[0.58rem] uppercase tracking-[0.32em] text-white/58">Instagram</p>
                    <p className="mt-1 font-serif text-2xl text-white">{image.title || "neilzzbyanto"}</p>
                  </div>
                </a>
              ))}
            </div>
          ) : (
            <div className="mt-9 grid gap-5 lg:grid-cols-[1fr_.7fr]">
              <div className="home-instagram-empty">
                <p className="lux-label">Așteaptă poze reale</p>
                <h3 className="editorial-title mt-4 text-4xl leading-[0.95] md:text-6xl">Când urci lucrările ei, aici apar ca postări.</h3>
                <p className="mt-5 max-w-xl text-sm leading-7 text-[var(--muted)]">Nu mai punem imagini random. Secțiunea rămâne curată și duce direct la profil până când sunt poze reale în dashboard.</p>
              </div>
              <a href={content.instagramUrl || INSTAGRAM_URL} target="_blank" rel="noopener noreferrer" className="home-instagram-profile-card">
                <span className="home-ig-dot" />
                <p className="lux-label">Profil oficial</p>
                <p className="editorial-title mt-8 text-5xl leading-[.9]">{content.instagramHandle || "@neilzz_by.anto"}</p>
                <span className="mt-7 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[.22em] text-[var(--rose-strong)]">Deschide Instagram <ArrowUpRight className="h-4 w-4" /></span>
              </a>
            </div>
          )}
        </div>
      </Reveal>
    </section>
  );
}

export default function Home() {
  const [gallery, setGalerie] = useState<GalerieImage[]>([]);
  const [bookingDays, setBookingDays] = useState<BookingDay[]>(fallbackBooking);
  const [siteSettings, setSiteSettings] = useState<SiteSettings>({ featuredClient: false, featuredDesign: true, featuredReview: true, publicBookingEnabled: true, appStatus: "active" });
  const [homepageContent, setHomepageContent] = useState<HomepageContent>(defaultHomepageContent);
  const [featuredReviews, setFeaturedReviews] = useState<PublicReview[]>([]);
  const [featuredClient, setFeaturedClient] = useState<FeaturedClient | null>(null);

  const { scrollYProgress } = useScroll();
  const heroLift = useTransform(scrollYProgress, [0, 0.34], [0, -46]);

  useEffect(() => {
    async function loadData() {
      const supabase = createClient();

      const { data: galleryData } = await supabase
        .from("gallery_images")
        .select("id,title,image_url")
        .eq("is_visible", true)
        .order("created_at", { ascending: false })
        .limit(8);
      if (galleryData && galleryData.length > 0) setGalerie(galleryData);

      const { data: bookingData } = await supabase
        .from("booking_days")
        .select("id,date_label,day_label,status,note,position")
        .eq("is_visible", true)
        .order("position", { ascending: true })
        .order("created_at", { ascending: false })
        .limit(5);
      if (bookingData && bookingData.length > 0) setBookingDays(bookingData);

      const [{ data: settingsData }, { data: contentData }] = await Promise.all([
        supabase.from("site_settings").select("value").eq("key", "homepage_features").maybeSingle(),
        supabase.from("site_settings").select("value").eq("key", "homepage_content").maybeSingle(),
      ]);

      if (settingsData?.value && typeof settingsData.value === "object") setSiteSettings((current) => ({ ...current, ...(settingsData.value as SiteSettings) }));
      if (contentData?.value && typeof contentData.value === "object") setHomepageContent((current) => ({ ...current, ...(contentData.value as HomepageContent) }));

      const { data: reviewData } = await supabase
        .from("reviews")
        .select("id,name,rating,text,is_featured,photo_url")
        .eq("is_approved", true)
        .order("is_featured", { ascending: false })
        .order("created_at", { ascending: false })
        .limit(3);
      if (reviewData && reviewData.length > 0) setFeaturedReviews(reviewData as PublicReview[]);

      const { data: clientData } = await supabase
        .from("profiles")
        .select("id,full_name,visit_count,avatar_url")
        .eq("role", "client")
        .eq("is_activated", true)
        .order("visit_count", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (clientData) setFeaturedClient(clientData as FeaturedClient);
    }

    loadData();
  }, []);

  const images = useMemo(() => gallery, [gallery]);
  const hasRealGallery = images.length > 0;
  const nextBooking = bookingDays[0] || fallbackBooking[0];

  return (
    <main className="app-shell-bg home-lux-bg relative min-h-screen overflow-x-hidden bg-[var(--bg)] text-[var(--text)]">
      <div className="lux-noise" />
      <div className="home-aurora-layer" />
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="soft-pulse absolute left-[8%] top-[7%] h-[24rem] w-[24rem] rounded-full bg-[var(--wine)]/42 blur-[140px]" />
        <div className="soft-pulse absolute right-[4%] top-[16%] h-[22rem] w-[22rem] rounded-full bg-[var(--rose)]/14 blur-[125px]" />
        <div className="absolute inset-x-0 top-0 h-px rose-line" />
      </div>

      <SiteHeader />

      <section className="relative z-10 px-5 pb-16 pt-[8.8rem] md:min-h-screen md:px-8 md:pb-20 md:pt-28">
        <SparkleField />
        <div className="mx-auto grid max-w-[1500px] items-center gap-10 lg:grid-cols-[0.82fr_1.18fr]">
          <motion.div style={{ y: heroLift }} className="relative z-10 max-w-3xl">
            <motion.div initial={false} animate={{ opacity: 1 }} className="inline-flex rounded-full border border-[var(--line)] bg-[var(--panel)] px-4 py-2 text-[0.62rem] font-bold uppercase tracking-[0.38em] text-[var(--rose-strong)] backdrop-blur-xl">
              {homepageContent.badge}
            </motion.div>
            <motion.h1 initial={false} animate={{ opacity: 1 }} className="editorial-title mt-7 max-w-3xl text-[3.65rem] leading-[0.88] sm:text-[4.05rem] lg:text-[4.75rem] xl:text-[5.25rem]">
              {homepageContent.titleLine1}<br />{homepageContent.titleLine2}
            </motion.h1>
            <motion.p initial={false} animate={{ opacity: 1 }} className="mt-7 max-w-lg text-base leading-8 text-[var(--muted)] md:text-[1.05rem] md:leading-9">{homepageContent.subtitle}</motion.p>
            <motion.div initial={false} animate={{ opacity: 1 }} className="mt-8 flex flex-col gap-3 sm:flex-row">
              <LuxuryButton href="/gallery" solid><Images className="h-4 w-4" />{homepageContent.primaryCta}</LuxuryButton>
              <LuxuryButton href={homepageContent.instagramUrl || INSTAGRAM_URL}><CalendarDays className="h-4 w-4" />{homepageContent.secondaryCta}</LuxuryButton>
            </motion.div>
            <div className="mt-8 grid max-w-xl gap-3 sm:grid-cols-3">
              <div className="home-stat-card"><Clock3 className="h-4 w-4 text-[var(--rose-strong)]" /><p>Programare privată</p></div>
              <div className="home-stat-card"><ShieldCheck className="h-4 w-4 text-[var(--rose-strong)]" /><p>Igienă strictă</p></div>
              <div className="home-stat-card"><Sparkles className="h-4 w-4 text-[var(--rose-strong)]" /><p>Finish premium</p></div>
            </div>
          </motion.div>

          {hasRealGallery ? <RealGalleryPreview images={images} /> : <AtelierPreview nextBooking={nextBooking} />}
        </div>
      </section>

      {siteSettings.publicBookingEnabled !== false && (
        <section className="relative z-10 px-5 pb-10 md:px-8 md:pb-14">
          <div className="mx-auto grid max-w-[1320px] gap-4 md:grid-cols-3">
            {bookingDays.slice(0, 3).map((day, index) => (
              <Reveal key={day.id} delay={index * 0.05}>
                <article className="lux-panel rounded-[2rem] p-5 transition hover:-translate-y-1">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="lux-label">{day.day_label || `Zi ${index + 1}`}</p>
                      <p className="mt-3 font-serif text-4xl">{displayDateLabel(day.date_label)}</p>
                    </div>
                    <span className={`inline-block h-3 w-3 rounded-full ${statusDotClass(day.status)}`} />
                  </div>
                  <span className={statusClass(day.status)}>{statusLabel(day.status, day.note)}</span>
                </article>
              </Reveal>
            ))}
          </div>
        </section>
      )}

      <InstagramBlock images={images} content={homepageContent} />

      <section className="relative z-10 px-5 py-12 md:px-8 md:py-16">
        <Reveal>
          <div className="lux-panel mx-auto grid max-w-[1320px] gap-8 rounded-[2.5rem] p-7 md:grid-cols-[.8fr_1.2fr] md:p-10">
            <div>
              <p className="lux-label">About Antonia</p>
              <h2 className="editorial-title mt-5 text-5xl leading-[0.92] md:text-7xl">2+ ani de atenție, igienă și perfecționare.</h2>
            </div>
            <div className="space-y-5 text-base leading-8 text-[var(--muted)]">
              <p>Sunt Antonia, iar neilzzbyanto este un atelier privat construit pentru cliente care vor un finish curat, discret și premium. Lucrez cu atenție la formă, structură și rezistență, nu pe grabă.</p>
              <div className="grid gap-3 sm:grid-cols-3">
                {["2+ ani experiență", "Cursuri & perfecționare", "Sterilizare strictă", "Materiale premium", "Experiență privată", "Clean finish"].map((item) => (
                  <div key={item} className="rounded-2xl border border-[var(--line)] bg-[var(--panel)] p-4"><ShieldCheck className="mb-3 h-5 w-5 text-[var(--rose-strong)]" /><p className="text-sm font-semibold text-[var(--text)]">{item}</p></div>
                ))}
              </div>
            </div>
          </div>
        </Reveal>
      </section>

      {siteSettings.featuredDesign !== false && hasRealGallery && (
        <section className="relative z-10 px-5 py-12 md:px-8 md:py-16">
          <div className="mx-auto max-w-[1500px]">
            <Reveal className="flex flex-col justify-between gap-7 md:flex-row md:items-end">
              <div><p className="lux-label">Galerie preview</p><h2 className="editorial-title mt-5 max-w-4xl text-5xl leading-[0.9] md:text-7xl">Work first.<br />Words second.</h2></div>
              <LuxuryButton href="/gallery">Open full gallery</LuxuryButton>
            </Reveal>
            <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {images.slice(0, 4).map((item, index) => (
                <Reveal key={item.id} delay={index * 0.07}>
                  <motion.a href="/gallery" whileHover={{ y: -8 }} className="group block overflow-hidden rounded-[1.8rem] border border-[var(--line)] bg-[var(--panel)] p-2.5 backdrop-blur-2xl md:rounded-[2rem] md:p-3">
                    <div className={index % 2 === 0 ? "relative aspect-[3/4] overflow-hidden rounded-[1.35rem]" : "relative aspect-[3/5] overflow-hidden rounded-[1.35rem]"}>
                      <Image src={item.image_url} alt={item.title || "neilzzbyanto"} fill sizes="(min-width: 1024px) 25vw, 85vw" className="object-cover opacity-88 saturate-[0.92] transition duration-1000 group-hover:scale-[1.04]" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/72 via-transparent to-transparent opacity-80" />
                      <div className="absolute bottom-5 left-5 right-5"><p className="font-serif text-2xl text-white md:text-3xl">{item.title || "neilzzbyanto set"}</p></div>
                    </div>
                  </motion.a>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {siteSettings.featuredReview !== false && featuredReviews.length > 0 && (
        <section className="relative z-10 px-5 py-12 md:px-8 md:py-16">
          <div className="mx-auto max-w-[1500px]">
            <Reveal className="flex flex-col justify-between gap-7 md:flex-row md:items-end">
              <div><p className="lux-label">Review-uri</p><h2 className="editorial-title mt-5 max-w-4xl text-5xl leading-[0.9] md:text-7xl">Real words.<br />No performance.</h2></div>
              <LuxuryButton href="/reviews">Read all</LuxuryButton>
            </Reveal>
            <div className="mt-12 grid gap-4 md:grid-cols-3">
              {featuredReviews.map((review, index) => (
                <Reveal key={review.id} delay={index * 0.07}>
                  <article className="lux-panel h-full overflow-hidden rounded-[2rem] p-5 md:rounded-[2.2rem]">
                    {review.photo_url && <div className="relative mb-5 aspect-[4/3] overflow-hidden rounded-[1.45rem] border border-[var(--line)]"><Image src={review.photo_url} alt={review.name || "Review photo"} fill sizes="(min-width: 768px) 33vw, 100vw" className="object-cover" /></div>}
                    <div className="flex items-center justify-between gap-4"><div className="flex gap-1 text-[var(--rose-strong)]">{Array.from({ length: review.rating || 5 }).map((_, star) => <Star key={star} className="h-4 w-4 fill-current" />)}</div>{review.is_featured && <span className="status-pill status-limited">Featured</span>}</div>
                    <p className="mt-7 text-xl leading-9 text-[var(--muted)]">“{review.text}”</p>
                    <div className="mt-9 flex items-center justify-between gap-4 border-t border-[var(--line)] pt-5"><p className="font-serif text-2xl">{review.name || "Clientă"}</p><span className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-[var(--faint)]"><CheckCircle2 className="h-4 w-4" />verified</span></div>
                  </article>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      <section className="relative z-10 px-5 py-12 md:px-8 md:py-16">
        <Reveal>
          <div className="relative mx-auto max-w-[1320px] overflow-hidden rounded-[2.4rem] border border-[var(--line)] bg-[var(--panel)] p-7 shadow-[0_50px_150px_var(--shadow)] backdrop-blur-2xl md:rounded-[3rem] md:p-16">
            <div className="absolute right-[-12%] top-[-28%] h-72 w-72 rounded-full bg-[var(--rose)]/14 blur-[100px]" />
            <div className="relative grid gap-9 md:grid-cols-[1fr_auto] md:items-center">
              <div><p className="lux-label">Booking</p><h2 className="editorial-title mt-5 max-w-5xl text-5xl leading-[0.9] md:text-7xl">Send the idea.<br />Leave with the finish.</h2><p className="mt-6 max-w-2xl text-base leading-8 text-[var(--muted)]">Programările se fac privat, direct pe Instagram, ca fiecare set să fie discutat curat înainte.</p></div>
              <LuxuryButton href={homepageContent.instagramUrl || INSTAGRAM_URL} solid><Camera className="h-4 w-4" />{homepageContent.instagramHandle || "Instagram"}</LuxuryButton>
            </div>
          </div>
        </Reveal>
      </section>

      <footer className="relative z-10 px-5 pb-28 pt-6 md:px-8 md:pb-10">
        <div className="mx-auto flex max-w-[1320px] justify-center">
          <img src="/neilzz-logo-light.png" alt="neilzzbyanto" className="h-14 w-auto object-contain opacity-80" />
        </div>
      </footer>

      <MobileBottomNav instagramUrl={homepageContent.instagramUrl || INSTAGRAM_URL} />
    </main>
  );
}
